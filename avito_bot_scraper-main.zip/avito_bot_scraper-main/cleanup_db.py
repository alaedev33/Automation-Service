# cleanup_db.py

import sqlite3
import database

def main():
    """
    Safely removes the old spec columns from the products table.
    This is the standard, safe way to "drop" columns in SQLite.
    """
    print("Starting database cleanup...")
    db_file = database.DATABASE_FILE
    
    try:
        conn = sqlite3.connect(db_file)
        cursor = conn.cursor()

        # 1. Start a transaction
        cursor.execute("BEGIN TRANSACTION;")
        
        # 2. Create a new table with the desired final schema
        print("  > Creating new temporary table...")
        cursor.execute("""
            CREATE TABLE products_new (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                url TEXT NOT NULL UNIQUE,
                title TEXT, price INTEGER, location TEXT,
                status TEXT NOT NULL,
                last_seen DATE,
                condition TEXT,
                description TEXT,
                is_deal INTEGER,
                ai_verdict TEXT
            );
        """)
        
        # 3. Copy the data from the old table to the new one, selecting only the columns we want to keep.
        print("  > Migrating data to new table...")
        cursor.execute("""
            INSERT INTO products_new (id, url, title, price, location, status, last_seen, condition, description, is_deal, ai_verdict)
            SELECT id, url, title, price, location, status, last_seen, condition, description, is_deal, ai_verdict
            FROM products;
        """)
        
        # 4. Drop the old table
        print("  > Dropping old table...")
        cursor.execute("DROP TABLE products;")
        
        # 5. Rename the new table to the original name
        print("  > Renaming new table...")
        cursor.execute("ALTER TABLE products_new RENAME TO products;")
        
        # 6. Commit the transaction
        conn.commit()
        print("\n✅ Database cleanup complete! Unused columns have been removed.")

    except sqlite3.Error as e:
        print(f"An SQLite error occurred: {e}")
        if conn:
            conn.rollback()
            print("Transaction rolled back.")
    finally:
        if conn:
            conn.close()

if __name__ == "__main__":
    main()
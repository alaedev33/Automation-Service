# reset_status.py

import database

def main():
    """Resets the status of all 'analyzed' listings back to 'details_scraped'."""
    
    print("Connecting to the database to reset statuses...")
    conn = None
    try:
        conn = database.create_connection()
        cur = conn.cursor()

        # This is the SQL command to find all analyzed items and revert their status
        sql_update_query = """
        UPDATE products 
        SET status = 'details_scraped' 
        WHERE status = 'analyzed'
        """
        
        cur.execute(sql_update_query)
        # The 'commit' call saves the changes to the database file
        conn.commit()
        
        # 'rowcount' tells us how many rows were affected by the last command
        reset_count = cur.rowcount
        print(f"✅ Successfully reset the status for {reset_count} listings.")
        print("You can now run 'exporter.py' again.")

    except Exception as e:
        print(f"An error occurred: {e}")
        if conn:
            # If anything goes wrong, undo the changes
            conn.rollback()
    finally:
        if conn:
            conn.close()

if __name__ == "__main__":
    main()
# Avito Reseller Bot

This is an advanced, automated bot designed to find profitable resale opportunities for tech products on Avito.ma. It uses a multi-stage pipeline involving web scraping, data processing, and AI-driven analysis to identify undervalued listings.

## Key Features

- **Multi-threaded Scraping:** Utilizes Python's `threading` and `playwright` to efficiently scrape multiple pages and listings in parallel.
- **Human-Assisted AI Analysis:** A unique workflow where the bot performs bulk data collection, and a human operator collaborates with an AI (like Google's Gemini or OpenAI's GPT) for high-level market analysis.
- **Data Persistence:** Uses SQLite to store and manage listings, ensuring data is not lost between runs.
- **Automated Workflow Management:** A suite of scripts (`scraper.py`, `exporter.py`, `importer.py`, `verifier.py`) to manage the entire data pipeline from collection to analysis and cleanup.
- **Deal Notifications:** Integrated with `ntfy.sh` to send real-time push notifications to a mobile device when a confirmed deal is found.

## How It Works

1.  **`scraper.py`**: The workhorse. It scrapes Avito for new listings based on defined search terms, gathering basic details like title, price, description, and condition.
2.  **`exporter.py`**: This script prepares the collected data for analysis, exporting it into manageable text files.
3.  **AI Analysis (Human-in-the-loop)**: The user takes the exported text file and uses it in a high-level AI chat interface to get expert-level analysis on each listing.
4.  **`importer.py`**: The user saves the AI's JSON response and runs this script to import the verdicts and justifications back into the database.
5.  **`verifier.py`**: A utility script to periodically check if listings are still active and remove sold/deleted ones to keep the dataset fresh.

## Technologies Used

- **Python 3**
- **Playwright:** For robust, browser-based web scraping.
- **BeautifulSoup4:** For parsing HTML.
- **SQLite3:** For database management.
- **Requests:** For simple HTTP operations.
- **OpenAI API / Google AI Studio:** (As the external analysis tool).

## Setup & Usage

1.  Clone the repository:
    ```bash
    git clone https://github.com/YOUR_USERNAME/avito-bot.git
    cd avito-bot
    ```
2.  Create a virtual environment:
    ```bash
    python -m venv venv
    venv\scripts\activate
    ```
3.  Install dependencies:
    ```bash
    pip install -r requirements.txt
    ```
4.  Create a `.env` file and add your `NTFY_TOPIC`.
5.  Run the pipeline:
    ```bash
    python scraper.py
    python exporter.py
    # Perform AI analysis manually
    python importer.py
    ```
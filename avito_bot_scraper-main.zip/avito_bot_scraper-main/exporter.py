# exporter.py

import database

def main():
    """Exports listings from the DB into a text file for AI analysis."""
    print("Connecting to database to export listings...")
    conn = None
    try:
        conn = database.create_connection()
        database.export_listings_for_analysis(conn)
    except Exception as e:
        print(f"An error occurred: {e}")
    finally:
        if conn:
            conn.close()
    print("Process complete. 'listings_to_analyze.txt' is ready.")

if __name__ == "__main__":
    main()
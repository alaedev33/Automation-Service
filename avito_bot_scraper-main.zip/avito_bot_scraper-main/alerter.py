# alerter.py

import requests

# IMPORTANT: Change this to your own secret topic name!
NTFY_TOPIC = "avito-deal-finder-2025-xyz"
NTFY_URL = f"https://ntfy.sh/{NTFY_TOPIC}"

def send_notification(title: str, message: str, url: str):
    """Sends a push notification via ntfy.sh"""
    try:
        requests.post(
            NTFY_URL,
            data=message.encode('utf-8'),
            headers={
                "Title": title.encode('utf-8'),
                "Priority": "high",
                "Tags": "tada",
                "Click": url
            }
        )
        print("  [🚀 Notification Sent!] ")
    except Exception as e:
        print(f"  [❌ Failed to send notification: {e}]")
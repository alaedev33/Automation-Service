# database.py (Final Lean Version)

import sqlite3
from datetime import date

DATABASE_FILE = "avito_deals.db"

def create_connection():
    """Creates a database connection with a timeout for multithreading."""
    return sqlite3.connect(DATABASE_FILE, timeout=10.0)

def initialize_database(conn):
    """Creates the final, simplified table for the lean workflow."""
    c = conn.cursor()
    c.execute("""
        CREATE TABLE IF NOT EXISTS products (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            url TEXT NOT NULL UNIQUE,
            title TEXT, 
            price INTEGER, 
            location TEXT,
            status TEXT NOT NULL DEFAULT 'new', -- new -> details_scraped -> analyzed
            last_seen DATE,
            condition TEXT,
            description TEXT,
            -- The only fields the AI will provide now
            is_deal INTEGER DEFAULT 0,
            ai_verdict TEXT
        );
    """)
    conn.commit()

def add_or_update_listing(conn, listing):
    """Inserts a new listing or updates an existing one."""
    today = date.today()
    cur = conn.cursor()
    cur.execute("SELECT id, status FROM products WHERE url = ?", (listing['url'],))
    data = cur.fetchone()
    if data is None:
        sql = ''' INSERT INTO products(url, title, price, location, last_seen, status)
                  VALUES(?,?,?,?,?, 'new') '''
        cur.execute(sql, (listing['url'], listing['title'], listing['price'], listing['location'], today))
    else:
        product_id, current_status = data
        if current_status == 'analyzed':
            sql = ''' UPDATE products SET last_seen = ?, price = ?, status = 'details_scraped' WHERE id = ? '''
            cur.execute(sql, (today, listing['price'], product_id))
        else:
            sql = ''' UPDATE products SET last_seen = ?, price = ? WHERE id = ? '''
            cur.execute(sql, (today, listing['price'], product_id))
    conn.commit()
    return cur.lastrowid is not None or cur.rowcount > 0

def get_new_listings_for_details(conn):
    """Gets all listings that need their details scraped."""
    cur = conn.cursor()
    cur.execute("SELECT id, url FROM products WHERE status = 'new'")
    return cur.fetchall()

def update_listing_details(conn, product_id, details):
    """Updates a listing with its scraped condition and description."""
    sql = ''' UPDATE products
              SET condition = ?, description = ?, status = 'details_scraped'
              WHERE id = ?'''
    cur = conn.cursor()
    cur.execute(sql, (details.get('condition', 'N/A'), details.get('description', ''), product_id))
    conn.commit()

# In database.py

# In database.py

def export_listings_for_analysis(conn, batch_size=300):
    """
    Exports listings into multiple text files, including the condition of the item.
    """
    cur = conn.cursor()
    # Add 'condition' to the SELECT statement
    cur.execute("SELECT id, url, title, price, condition, description FROM products WHERE status = 'details_scraped'")
    listings = cur.fetchall()

    if not listings:
        print("No new listings to export for analysis.")
        return

    total_files = (len(listings) + batch_size - 1) // batch_size
    print(f"Found {len(listings)} listings to export. This will create {total_files} file(s).")

    for i in range(total_files):
        start_index = i * batch_size
        end_index = start_index + batch_size
        current_batch = listings[start_index:end_index]
        
        file_number = i + 1
        filename = f"listings_to_analyze_{file_number}.txt"
        
        output_text = ""
        # Unpack the new 'condition' variable
        for id, url, title, price, cond, desc in current_batch:
            # Add the 'Condition' line to the output text
            output_text += f"ID: {id}\nURL: {url}\nTitle: {title}\nPrice: {price} MAD\nCondition: {cond}\nDescription: {desc}\n---\n"
            
        try:
            with open(filename, "w", encoding="utf-8") as f:
                f.write(output_text)
            print(f"  > Successfully created '{filename}' with {len(current_batch)} listings.")
        except Exception as e:
            print(f"  > Error writing to file '{filename}': {e}")

def update_from_ai_analysis(conn, analysis_data):
    """Updates a record using its ID from the AI's lean JSON output."""
    sql = ''' UPDATE products
              SET is_deal = ?, ai_verdict = ?, status = 'analyzed'
              WHERE id = ?'''
    cur = conn.cursor()
    try:
        product_id = analysis_data.get('id')
        if product_id is None:
            print(f"Skipping update: analysis object missing 'id'. Data: {analysis_data}")
            return False
            
        cur.execute(sql, (
            analysis_data.get('is_deal', 0),
            analysis_data.get('ai_verdict', 'Analysis failed.'),
            product_id
        ))
        conn.commit()
        return cur.rowcount > 0
    except Exception as e:
        print(f"Error updating DB for id {analysis_data.get('id')}: {e}")
        return False
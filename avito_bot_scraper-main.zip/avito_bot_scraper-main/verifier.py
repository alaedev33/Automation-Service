# verifier.py

import requests
import database

def main():
    """Checks all listings in the DB and removes ones that are no longer active (404)."""
    conn = database.create_connection()
    cur = conn.cursor()
    cur.execute("SELECT id, url FROM products")
    all_listings = cur.fetchall()
    
    deleted_count = 0
    print(f"Verifying {len(all_listings)} total listings...")
    
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'}
    for product_id, url in all_listings:
        try:
            # Use HEAD request for speed as we don't need the body
            response = requests.head(url, headers=headers, timeout=10, allow_redirects=True)
            if response.status_code == 404:
                print(f"  > Listing {product_id} is GONE (404). Deleting...")
                cur.execute("DELETE FROM products WHERE id = ?", (product_id,))
                deleted_count += 1
        except requests.RequestException:
            print(f"  > Failed to connect to {url}. Skipping.")
    
    conn.commit()
    conn.close()
    print(f"\nVerification complete. Deleted {deleted_count} inactive listings.")

if __name__ == "__main__":
    main()
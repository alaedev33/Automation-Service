# scraper.py (With Stop Signal for Efficiency)

import time
import queue
import threading
from playwright.sync_api import sync_playwright
from bs4 import BeautifulSoup, NavigableString
import database

# --- CONFIG ---
SEARCH_TERMS = ["rtx", "pc gamer", "gtx", "carte graphic", "pc portable"]
AVITO_BASE_URL = "https://www.avito.ma/fr/maroc/{}"
MAX_PAGES_PER_TERM = 1000 # Set a high limit, the bot will stop when it finds an empty page
MAX_WORKER_THREADS = 3   # Adjust based on your PC's power (2-4 is safe)
PAGE_TIMEOUT = 50000     # 50 seconds

# --- SELECTORS ---
LISTINGS_CONTAINER_SELECTOR = "div.sc-bkuk8l-0"
AD_CARD_SELECTOR = "a.sc-1jge648-0"
CONDITION_SELECTOR = "div.sc-19cngu6-0 span.fjZBup"
DESCRIPTION_SELECTOR = "div.sc-ij98yj-0"
PRICE_SELECTOR = 'p.dJAfqm'

# --- HELPER FUNCTIONS ---
def parse_price(price_element):
    if not price_element: return None
    price_texts = price_element.find_all(string=True, recursive=False)
    for text in price_texts:
        if isinstance(text, NavigableString) and any(char.isdigit() for char in text):
            try: return int(''.join(filter(str.isdigit, text)))
            except (ValueError, TypeError): continue
    try: return int(''.join(filter(str.isdigit, price_element.get_text())))
    except (ValueError, TypeError): return None

def parse_search_listings(html_content):
    soup = BeautifulSoup(html_content, 'html.parser')
    listings_container = soup.select_one(LISTINGS_CONTAINER_SELECTOR)
    if not listings_container: return []
    ad_cards = listings_container.select(AD_CARD_SELECTOR)
    clean_listings = []
    for card in ad_cards:
        href = card.get('href', '')
        url = "https://www.avito.ma" + href if not href.startswith('http') else href
        title_el = card.find('p', class_='iHApav') or card.find('h2')
        title = title_el.get_text(strip=True) if title_el else "N/A"
        location_div = card.find('div', class_='sc-b57yxx-11')
        location = location_div.find('p').get_text(strip=True).replace('dans ', '') if location_div else "N/A"
        price_element = card.select_one(PRICE_SELECTOR)
        price = parse_price(price_element)
        if price is None or price < 100: continue
        clean_listings.append({"title": title, "price": price, "location": location, "url": url})
    return clean_listings

def parse_details_page(html_content):
    soup = BeautifulSoup(html_content, 'html.parser')
    condition_el = soup.select_one(CONDITION_SELECTOR)
    condition = condition_el.get_text(strip=True) if condition_el else "N/A"
    condition_std = "N/A"
    if "neuf" in condition.lower(): condition_std = "New"
    elif any(s in condition.lower() for s in ["bon", "utilisé", "occasion"]): condition_std = "Used"
    description_el = soup.select_one(DESCRIPTION_SELECTOR)
    description = description_el.get_text(separator='\n', strip=True) if description_el else ""
    return {"condition": condition_std, "description": description}

# --- WORKER FUNCTIONS ---
def search_page_worker(q, db_lock, completed_terms):
    db_conn = database.create_connection()
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        page = browser.new_page()
        while True:
            try:
                url, term, page_num = q.get(timeout=1)

                # Check the stop signal before doing any work
                if term in completed_terms:
                    q.task_done() # Mark job as done and skip it
                    continue

                page.goto(url, timeout=PAGE_TIMEOUT)
                listings = parse_search_listings(page.content())
                
                # If no listings, add to completed set and move on
                if not listings:
                    print(f"  > '{term}' p{page_num}: No listings found. Marking term as complete.", flush=True)
                    completed_terms.add(term)
                    q.task_done()
                    continue

                with db_lock:
                    new_found = sum(1 for listing in listings if database.add_or_update_listing(db_conn, listing))
                print(f"  > '{term}' p{page_num}: Found {len(listings)}, added {new_found} new.", flush=True)
                q.task_done()
            except queue.Empty:
                break # Queue is empty, this worker's job is done
            except Exception as e:
                # Still mark task as done so the main thread doesn't hang
                print(f"    [!] Search worker error on page {page_num} for term '{term}': {e}", flush=True)
                q.task_done()
        browser.close()
    db_conn.close()

def detail_scraper_worker(q, db_lock):
    db_conn = database.create_connection()
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        page = browser.new_page()
        while True:
            try:
                product_id, url = q.get(timeout=1)
                page.goto(url, timeout=PAGE_TIMEOUT)
                details = parse_details_page(page.content())
                if details:
                    with db_lock:
                        database.update_listing_details(db_conn, product_id, details)
                print(f"  > Scraped details: {url[:50]}...", flush=True)
                q.task_done()
            except queue.Empty:
                break
            except Exception as e:
                print(f"    [!] Detail worker error for {url}: {e}", flush=True)
                q.task_done()
        browser.close()
    db_conn.close()

# --- MAIN WORKFLOW ---
def main():
    db_conn = None
    try:
        db_conn = database.create_connection()
        database.initialize_database(db_conn)
        db_lock = threading.Lock()
        completed_terms = set() # Create the shared set for the stop signal

        # Phase 1: Ingestion
        print("--- PHASE 1: INGESTION (THREADED) ---")
        search_queue = queue.Queue()
        for term in SEARCH_TERMS:
            # We put all potential pages in the queue. The workers will figure out when to stop.
            for page_num in range(1, MAX_PAGES_PER_TERM + 1):
                url = f"{AVITO_BASE_URL.format(term.replace(' ', '-'))}?o={page_num}"
                search_queue.put((url, term, page_num))
        
        # Pass the 'completed_terms' set to each worker
        threads = [threading.Thread(target=search_page_worker, args=(search_queue, db_lock, completed_terms)) for _ in range(MAX_WORKER_THREADS)]
        for t in threads: t.start()
        search_queue.join() # Wait for all tasks in the queue to be marked as done
        for t in threads: t.join() # Wait for all threads to finish their cleanup

        # Phase 2: Detail Scraping
        print("\n--- PHASE 2: SCRAPING DETAILS (THREADED) ---")
        listings_to_detail = database.get_new_listings_for_details(db_conn)
        if listings_to_detail:
            print(f"Found {len(listings_to_detail)} listings to scrape for details. Starting workers...")
            detail_queue = queue.Queue()
            for item in listings_to_detail:
                detail_queue.put(item)
            
            threads = [threading.Thread(target=detail_scraper_worker, args=(detail_queue, db_lock)) for _ in range(MAX_WORKER_THREADS)]
            for t in threads: t.start()
            detail_queue.join()
            for t in threads: t.join()
        
        print("\n--- ✅ SCRAPER FINISHED FULL RUN ---")
        if listings_to_detail:
             print(f"--- Run 'python exporter.py' to prepare listings for AI analysis. ---")
        else:
             print("--- No new listings found to analyze. ---")

    except KeyboardInterrupt:
        print("\n--- 🛑 SCRAPER INTERRUPTED BY USER. ---")
    finally:
        if db_conn:
            db_conn.close()

if __name__ == "__main__":
    main()
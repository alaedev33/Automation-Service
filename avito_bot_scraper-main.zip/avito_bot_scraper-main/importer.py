# In importer.py

import json
import database
import alerter
import glob # Import the glob library to find files matching a pattern

def main():
    """Imports AI analysis results from multiple JSON files into the database."""
    # Find all files that match the pattern "ai_analysis_results_*.json"
    json_files = glob.glob("ai_analysis_results_*.json")

    if not json_files:
        print("Error: No 'ai_analysis_results_*.json' files found. Please create these files with the AI's responses.")
        return

    conn = database.create_connection()
    cur = conn.cursor()
    total_updated = 0
    total_deals = 0

    for file_path in json_files:
        print(f"\n--- Processing file: {file_path} ---")
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                results = json.load(f)
        except Exception as e:
            print(f"Error reading or parsing {file_path}: {e}")
            continue

        file_updated = 0
        file_deals = 0
        for analysis_data in results:
            if database.update_from_ai_analysis(conn, analysis_data):
                file_updated += 1
                if analysis_data.get('is_deal') == 1:
                    file_deals += 1
                    # ... (notification logic is the same)
        
        total_updated += file_updated
        total_deals += file_deals
        print(f"  > Imported {file_updated} records from this file.")

    conn.close()
    print(f"\nSuccessfully imported and updated a total of {total_updated} records from {len(json_files)} file(s).")
    if total_deals > 0:
        print(f"Found and sent notifications for a total of {total_deals} new deals!")

if __name__ == "__main__":
    main()
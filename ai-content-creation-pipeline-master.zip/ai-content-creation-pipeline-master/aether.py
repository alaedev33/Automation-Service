import os
import requests
from openai import OpenAI
from config.config import API_KEY, DATABASE_FILE_PATH, OUTPUT_CONTENT_DIR, NEWS_API_KEY
import re
import sqlite3
from datetime import datetime
from bs4 import BeautifulSoup
import json
import logging

# Setup basic logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# Verify that all the values were loaded
if not all([API_KEY, DATABASE_FILE_PATH, OUTPUT_CONTENT_DIR, NEWS_API_KEY]):
    raise ValueError("Not all the values from the config file were loaded correctly")

# Initialize the API client
client = OpenAI(api_key=API_KEY)

def get_ai_response(prompt, model="gpt-4o-mini"):
    """Sends a prompt to the AI and returns the response using the OpenAI API."""
    try:
        logging.info(f"Sending prompt to OpenAI: {prompt[:100]}...")
        completion = client.chat.completions.create(
            model=model,
            messages=[
                {"role": "user", "content": prompt}
            ]
        )
        response = completion.choices[0].message.content.strip()
        logging.info(f"Received response from OpenAI: {response[:100]}...")
        return response

    except Exception as e:
        logging.error(f"Error fetching AI response: {e}")
        return None

def sanitize_filename(filename):
    """Sanitizes a filename to remove invalid characters."""
    # Replace invalid characters with underscores
    sanitized_filename = re.sub(r'[<>:"/\\|?*\x00-\x1F]', '_', filename)

    # Remove any leading or trailing spaces
    sanitized_filename = sanitized_filename.strip()

    # Truncate filename if it's too long (optional)
    sanitized_filename = sanitized_filename[:200]  # Increased length to 200

    # Replace multiple consecutive underscores with a single one
    sanitized_filename = re.sub(r'_+', '_', sanitized_filename)


    #Remove periods at the beggining and the end of the string
    sanitized_filename = sanitized_filename.strip(".")

    return sanitized_filename

def get_trending_topic_from_newsapi(category=None):
    """Gets a trending topic from NewsAPI for specified category."""
    if category is None:
        category = "entertainment"

    viral_keywords = ["shocking", "amazing", "controversial", "unexpected", "unbelievable", "rare", "incredible",
                      "scandal", "drama", "feud", "breakup", "secret", "exclusive"]

    try:
        logging.info(f"Fetching trending topic for category: {category}")
        response = requests.get(
            "https://newsapi.org/v2/top-headlines",
            params={
                "apiKey": NEWS_API_KEY,
                "country": "us",
                "category": category,
                "sortBy": "publishedAt",
            }, timeout=10
        )
        response.raise_for_status()
        articles = response.json()["articles"]

        # Simple Time-Based filter
        recent_articles = []
        for article in articles:
            published_at = datetime.fromisoformat(article["publishedAt"].replace("Z", "+00:00"))
            time_difference = datetime.now(published_at.tzinfo) - published_at
            if time_difference.total_seconds() <= 48 * 60 * 60:
                recent_articles.append(article)

        # Apply viral potential filtering
        for article in recent_articles:
            title = article["title"].lower()
            if any(keyword in title for keyword in viral_keywords):
                logging.info(f"Found viral topic for {category}: {article['title']}")
                return article  # Return the first viral article

        # If no viral topics, return the first regular topic
        if recent_articles:
            logging.info(f"Found regular topic for {category}: {recent_articles[0]['title']}")
            return recent_articles[0]

        logging.warning(f"Could not retrieve trending topic for category: {category}")
        return None

    except requests.exceptions.RequestException as e:
        logging.error(f"Error fetching trending topic for category {category}: {e}")
        return None

def save_content_to_db(title, content_type, file_path, conn, cursor, source=None):
    """Saves content information to the SQLite database."""
    try:
        cursor.execute('''
            INSERT INTO content (title, type, file_path, source)
            VALUES (?, ?, ?, ?)
        ''', (title, content_type, file_path, source))
        conn.commit()
        logging.info(f"Content Saved in Database: {title}, Type: {content_type}, Path: {file_path}")
        return cursor.lastrowid
    except Exception as e:
        logging.error(f"There was an error saving the content to the database: {e}")
        return None

def fetch_article_content(article):
    """Fetches the article content from the URL using BeautifulSoup."""
    article_url = article.get("url")
    if not article_url:
        logging.warning(f"No URL found for article: {article.get('title', 'No Title')}")
        return None

    try:
        logging.info(f"Fetching article content from: {article_url}")
        response = requests.get(article_url, timeout=10)
        response.raise_for_status()
        soup = BeautifulSoup(response.content, 'html.parser')

        # Attempt to extract the main article text. This might need to be adjusted
        # based on the site's HTML structure.
        paragraphs = soup.find_all('p')
        article_text = "\n".join([p.get_text() for p in paragraphs])

        if not article_text:
            logging.warning(f"Could not extract article content from {article_url}")
            return None

        return article_text

    except requests.exceptions.RequestException as e:
        logging.error(f"Error fetching article content from {article_url}: {e}")
        return None

def create_long_form_script(article):
    """Generates a script for an entertaining long-form YouTube video based on a single article."""
    title = article.get("title", "No Title")
    article_content = fetch_article_content(article)

    if not article_content:
        logging.warning(f"Could not fetch content for article: {title}. Skipping script generation.")
        return None

    script_prompt = f"""Create a detailed script for an *entertaining* long-form YouTube video focusing on the following news story. The script should be:

    - Very detailed for long-form content (more than 15 mins long)
    - Have an engaging and humorous introduction to hook the viewer.
    - Provide context and analysis in an accessible and engaging manner.
    - Have an entertaining and engaging tone, using humor, wit, and storytelling techniques, and cliffhangers to keep the viewer interested.
    - Incorporate relevant background information and trivia to add depth.
    - End with a strong conclusion that summarizes key points and leaves the viewer with a thought-provoking question or humorous observation.
    - Provide specific suggestions for B-roll footage, visual gags, and other visual elements to enhance the viewing experience.
    - do not add any thing othere than the script of the host dont add any titles or description only what it should been said by the host.
    News Story Title: {title}
    News Story Content: {article_content}

    Emphasize making the script highly entertaining and engaging. Tell a compelling story!
    """

    long_form_script = get_ai_response(script_prompt, model="gpt-4o-mini")
    if long_form_script:
        return long_form_script
    else:
        logging.error("Could not generate long-form script.")
        return None

def generate_media_prompts(script):
    """Generates prompts for images based on the script."""
    prompt = f"""Given the following script for an entertaining long video, generate a series of specific image prompts to be used to generate the visual part of the video with the Leonardo AI API:

       Script: {script}
        Estimate the length of the audio by the length of the script.
        Generate at least one image prompt every 5 seconds of the script. (If the video is under 5 seconds, then at least one prompt.)
        Try to generate the image prompts in a way that follows the video narrative.
        Each image should be visually striking, emotionally engaging, and attention-grabbing to keep the viewer watching.
        Use dramatic lighting, intense facial expressions, and action-driven compositions to enhance engagement.  Incorporate humor and visual gags where appropriate.
        Include very detailed descriptions of what should be displayed in the images.
        Each prompt should be in a new line and should be very well described.
        Always return the prompts as a list.
        a prompt for an image should be used as the thumbnail for the long video. The thumbnail should be the most dramatic, humorous, and engaging image, designed to get the highest CTR and impressions. Also if the image containe some text in the image it should be glowing.

       """

    ai_response = get_ai_response(prompt, model="gpt-4o-mini")
    if ai_response:
        #Clean the response
        prompts = [line.strip() for line in ai_response.splitlines() if line.strip()]
        logging.info(f"Image prompts: {prompts}")
        return prompts
    else:
        logging.error("Could not retrieve image prompts")
        return []

def generate_youtube_search_queries(script, topic):
    """Generates search queries for YouTube and Google to find relevant videos."""
    prompt = f"""Given the following script for a YouTube video about '{topic}', generate a list of search queries that can be used on YouTube and Google to find relevant B-roll footage, news clips, interviews, and other visual assets. Include queries for:

    - Generic footage related to the overall topic.
    - Specific events, people, or places mentioned in the script.
    - Visual gags, humorous moments, and B-roll that would enhance the viewing experience.
    - Any relevant archival footage or historical context.

    Script: {script}

    Return each query on a new line."""

    ai_response = get_ai_response(prompt, model="gpt-4o-mini")
    if ai_response:
        search_queries = [line.strip() for line in ai_response.splitlines() if line.strip()]
        logging.info(f"Search queries: {search_queries}")
        return search_queries
    else:
        logging.error("Could not generate search queries.")
        return []

def process_article_for_long_form(article, conn, cursor, output_dir, category):
    """Processes a single article to create a long-form video script and image prompts."""
    title = article.get("title", "No Title")
    # Step 1: Generate Long-Form Script
    long_form_script = create_long_form_script(article)
    if not long_form_script:
        logging.error("Failed to generate long-form script.  Aborting.")
        return False

    # Step 2: Save the Script
    category_dir = os.path.join(output_dir, sanitize_filename(category))
    os.makedirs(category_dir, exist_ok=True)
    video_dir = os.path.join(category_dir, "long_form_videos")
    os.makedirs(video_dir, exist_ok=True)

    video_title = sanitize_filename(f"{title}_long_form_video")
    script_file_path = os.path.join(video_dir, f"{video_title}_script.txt")

    with open(script_file_path, "w", encoding="utf-8") as f:
        f.write(long_form_script)
    save_content_to_db(video_title, "long-form-script", script_file_path, conn, cursor)
    logging.info(f"Long-form script saved to {script_file_path}")

    # Step 3: Generate Prompts for Images
    prompts = generate_media_prompts(long_form_script)
    if prompts:
        prompts_output_path = os.path.join(video_dir, f"{video_title}_image_prompts.txt")
        with open(prompts_output_path, "w", encoding="utf-8") as f:
            f.write("\n".join(prompts))
        logging.info(f"Image prompts saved to {prompts_output_path}")
    else:
        logging.error(f"Could not generate image prompts for {video_title}")

    # Step 4: Generate YouTube search queries
    search_queries = generate_youtube_search_queries(long_form_script, title)
    if search_queries:
        queries_output_path = os.path.join(video_dir, f"{video_title}_search_queries.txt")
        with open(queries_output_path, "w", encoding="utf-8") as f:
            f.write("\n".join(search_queries))
        logging.info(f"YouTube search queries saved to {queries_output_path}")
    else:
        logging.error(f"Could not generate YouTube search queries for {video_title}")
    return True  # Indicate success

if __name__ == '__main__':
    logging.info("Aether is running in celebrity news mode for long-form content.")

    conn = sqlite3.connect(DATABASE_FILE_PATH)
    cursor = conn.cursor()

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS content (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT,
            type TEXT,
            file_path TEXT,
            source TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    ''')

    # Define the category you want to use here:
    target_category = "entertainment"

    # Get a trending topic from the specified category
    trending_article = get_trending_topic_from_newsapi(category=target_category)

    if trending_article:
        output_dir = OUTPUT_CONTENT_DIR  # Use the main output directory
        os.makedirs(output_dir, exist_ok=True)

        logging.info(f"Processing article for category: {target_category}")
        process_article_for_long_form(trending_article, conn, cursor, output_dir, target_category)
    else:
        logging.warning("No trending article found.  Stopping.")

    conn.close()
    logging.info("Aether finished running.")
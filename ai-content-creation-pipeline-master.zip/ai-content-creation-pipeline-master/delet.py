import sqlite3
from config.config import DATABASE_FILE_PATH

def delete_long_form_content_entry(category):
    try:
        conn = sqlite3.connect(DATABASE_FILE_PATH)
        cursor = conn.cursor()
        cursor.execute("DELETE FROM long_form_content WHERE category = ?", (category,))
        conn.commit()
        print(f"Successfully deleted long-form content entry for category: {category}")
    except Exception as e:
        print(f"Error deleting long-form content entry: {e}")
    finally:
        if conn:
            conn.close()

if __name__ == '__main__':
    category_to_delete = "business"  # Replace with the actual category if needed
    delete_long_form_content_entry(category_to_delete)
    print("Now, run your aether.py script.")
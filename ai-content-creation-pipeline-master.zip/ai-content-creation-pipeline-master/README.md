# 🤖 Automated News-to-Video Script Pipeline

This Python script automates the process of creating video-ready content from the latest news headlines. It fetches news, decides if it's worth a script, generates the script, creates text-to-speech audio, and prepares image prompts for a video montage.

## 📜 The Pipeline

1.  **Fetch News:** Scraps top headlines from a chosen category using **NewsAPI**.
2.  **AI Analysis:** Feeds the news article to **GPT**, which determines its suitability for a short-form video and generates a concise, engaging script if it's a good candidate.
3.  **Text-to-Speech:** Sends the generated script to the **ElevenLabs API** to create a high-quality audio narration.
4.  **Audio Enhancement:** (Optional) Speeds up the generated audio by 1.2x using **FFMPEG** for a more dynamic pace.
5.  **Image Prompt Generation:** Calculates the required number of images for a smooth video (1 image every 5 seconds) and asks **GPT** to generate descriptive prompts for each image based on the script.
6.  **Montage (Manual Step):** The generated audio and image prompts are ready to be used with a video editor or an image/video generation service like **Leonardo.AI** or **Midjourney** to create the final video.

## 🛠️ Tech Stack & Services

-   **Language:** Python
-   **APIs:**
    -   [OpenAI](https://openai.com/): For script and prompt generation.
    -   [NewsAPI](https://newsapi.org/): For fetching news articles.
    -   [ElevenLabs](https://elevenlabs.io/): For text-to-speech.
-   **Libraries:** `requests`, `python-dotenv`, `openai`, `elevenlabs-python`, `moviepy`
-   **External Tools:** `ffmpeg` (must be installed on your system).

## 🚀 Setup and Installation

1.  **Clone the repository:**
    ```bash
    git clone https://github.com/your-username/ai-content-creation-pipeline.git
    cd ai-content-creation-pipeline
    ```

2.  **Install FFMPEG:** You must have FFMPEG installed and available in your system's PATH.
    -   **MacOS:** `brew install ffmpeg`
    -   **Windows:** Download from the [official site](https://ffmpeg.org/download.html) and add to your PATH.
    -   **Linux:** `sudo apt update && sudo apt install ffmpeg`

3.  **Install Python dependencies:**
    ```bash
    pip install -r requirements.txt
    ```

4.  **Set up environment variables:**
    -   Create a file named `.env` in the root directory.
    -   Copy the contents of `.env.example` into `.env`.
    -   Add your API keys:
        ```
        OPENAI_API_KEY=your_openai_key
        NEWS_API_KEY=your_newsapi_key
        ELEVENLABS_API_KEY=your_elevenlabs_key
        ```

## 🏃‍♀️ How to Run

Execute the main script from your terminal:
```bash
python src/main.py
```
Check the `output/` folder for the generated audio file and the console for the image prompts.

## 📄 License

This project is licensed under the MIT License. See the [LICENSE](LICENSE) file for details.
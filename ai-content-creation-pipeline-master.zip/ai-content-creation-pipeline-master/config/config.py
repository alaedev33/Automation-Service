from pathlib import Path
import os
from dotenv import load_dotenv

# Construct the absolute path to the .env file
dotenv_path = Path(__file__).resolve().parent.parent / '.env'
# Load environment variables from .env file
load_dotenv(dotenv_path)

# Get environment variables or set a default value if not found
API_KEY = os.getenv("API_KEY", "")
GOOGLE_TRENDS_URL = os.getenv("GOOGLE_TRENDS_URL", "")
WEBSITE_URL = os.getenv("WEBSITE_URL", "")
BLOG_POST_TEMPLATE_PATH = os.getenv("BLOG_POST_TEMPLATE_PATH", "")
EBOOK_TEMPLATE_PATH = os.getenv("EBOOK_TEMPLATE_PATH", "")
DATABASE_FILE_PATH = os.getenv("DATABASE_FILE_PATH", "")
NEWS_API_KEY = os.getenv("NEWS_API_KEY", "")
PEXELS_API_KEY = os.getenv("PEXELS_API_KEY", "") # Added Pexels API key


# Get the ElevenLabs API keys
ELEVEN_LABS_API_KEYS = []
i = 1
while True:
    key = os.getenv(f"ELEVEN_LABS_API_KEY_{i}")
    if key:
        ELEVEN_LABS_API_KEYS.append(key)
        i += 1
    else:
        break

# Create paths to the directory of the current file and other folders.
BASE_DIR = Path(__file__).resolve().parent
PROMPT_TEMPLATES_DIR = os.path.join(BASE_DIR, "prompts")
OUTPUT_CONTENT_DIR = os.path.join(BASE_DIR.parent, "output_content")
DATABASE_DIR = os.path.join(BASE_DIR.parent, "database")

# Load Prompt Templates
try:
    with open(BLOG_POST_TEMPLATE_PATH, "r", encoding="utf-8") as f:
        BLOG_POST_TEMPLATE = f.read()
    with open(EBOOK_TEMPLATE_PATH, "r", encoding="utf-8") as f:
        EBOOK_TEMPLATE = f.read()
except Exception as e:
    raise ValueError(f"There was an error trying to load the prompts: {e}")

# Verify that all the environment variables were loaded successfully
if not all([API_KEY, GOOGLE_TRENDS_URL, WEBSITE_URL, BLOG_POST_TEMPLATE_PATH, EBOOK_TEMPLATE_PATH, DATABASE_FILE_PATH, BLOG_POST_TEMPLATE, EBOOK_TEMPLATE, NEWS_API_KEY, ELEVEN_LABS_API_KEYS, PEXELS_API_KEY]): # Added PEXELS_API_KEY and ELEVEN_LABS_API_KEYS in the check.
   raise ValueError("Not all the environment variables were loaded. Please check the .env file.")